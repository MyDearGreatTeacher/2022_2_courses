# 載入必要套件
from Data import getDataYF,getDataFM
from BackTest import ChartTrade,Performance
import pandas as pd
import mplfinance as mpf
from talib.abstract import EMA

# 取得回測資料
prod='0050'
data=getDataFM(prod,'2007-01-01','2022-05-01')

# 計算指數移動平均線
data['ema']=EMA(data,timeperiod=120)
                   
# 繪製副圖
addp=[]
addp.append(mpf.make_addplot(data['ema']))

# 繪製K線圖與交易明細
ChartTrade(data,addp=addp)


