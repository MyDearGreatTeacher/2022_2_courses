﻿# !/usr/bin/env python
# coding=utf-8
import numpy as np
print(np.arange(0,1,0.1))
for val in np.arange(1,3,0.5):
    print(val)