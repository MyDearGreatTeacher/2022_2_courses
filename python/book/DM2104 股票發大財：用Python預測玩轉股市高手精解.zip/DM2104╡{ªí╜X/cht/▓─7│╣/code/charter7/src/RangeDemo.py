﻿# !/usr/bin/env python
# coding=utf-8
# ʤ㶰彴儕늽㬵벻༺쵍
for val in range(0,5): 
# 劫ۦor val in range(0,5,1):    
    print(val)
# ʤ㶰,2,4
for val in range(0,5,2):
    print(val)
# ȧς亂뻡㶴���ҲΪrange⻖糖衶Ѝ
for val in range(0,5,0.5):
    print(val)