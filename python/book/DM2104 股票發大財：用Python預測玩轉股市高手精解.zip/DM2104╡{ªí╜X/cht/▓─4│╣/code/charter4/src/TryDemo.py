﻿# !/usr/bin/env python
# coding=utf-8
stockInfoList = ['600001','600002']
try:
    stockInfoList.remove('600003')
except: 
    print('Could not Remove from List')
print('following job')      