﻿# !/usr/bin/env python
import django
print(django.get_version())