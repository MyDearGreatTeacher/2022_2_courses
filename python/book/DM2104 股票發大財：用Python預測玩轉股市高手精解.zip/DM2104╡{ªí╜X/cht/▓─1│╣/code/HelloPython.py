﻿# coding=utf-8
# Print Hello World
print("Hello World")
'''
1到10的累加和
'''   
    #sum = 0
sum = 0
for i in range(11):
#sum += i
    sum += i
print sum

