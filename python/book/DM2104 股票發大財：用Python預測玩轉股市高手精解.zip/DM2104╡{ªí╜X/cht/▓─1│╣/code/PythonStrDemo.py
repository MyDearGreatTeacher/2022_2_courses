﻿# !/usr/bin/env python
# coding=utf-8

str = 'My String'

print str        # 輸出完整字串
print str[0]     # 輸出第1個字元M 
print str[3:9]   # 輸出第3至第9個字串，即String
print str[3:]    # 輸出第3至最後的字串，也是String
print str * 2    # 輸出字串2次，但這種寫法不常用
print "He"+"llo" # 字串連線，輸出Hello
