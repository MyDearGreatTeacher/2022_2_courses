﻿# coding=utf-8
# 示範基本資料型態

age = 12    # 整數型態
# age = 15.5 錯誤的用法
print age   # 列印12  
price = 69.8   # 浮點型
print price    # 列印69.8 
distance = 20L # 長整數
print distance # 列印20   
isMarried = True # 布爾型態
print isMarried  # 列印True
msg = "Hello"  # 字串
print msg      # Hello

