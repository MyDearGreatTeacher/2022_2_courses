﻿# !/usr/bin/env python
# coding=utf-8
print(1+1) 	    # 輸出是1
print("1"+"1")  # 輸出是11
areaList=["ShangHai","HangZhou"]
print(areaList) 	# print能適用於不同型態的參數
print("abc".index("a"))
print(["a","b","c"].index("b"))