﻿# !/usr/bin/env python
# coding=utf-8
E = 2.718
G = 9.8

def calGravity (m):
    return m*G
