import requests, json
import pandas as pd

url = "https://tcgbusfs.blob.core.windows.net/dotapp/youbike/v2/youbike_immediate.json"

r = requests.get(url)
r.encoding = "utf-8"
data = json.loads(r.text)
df = pd.DataFrame(data)
print("下載Youbike2的JSON資料...")
df.to_csv("Youbike2.csv",index=False,encoding="utf8")

