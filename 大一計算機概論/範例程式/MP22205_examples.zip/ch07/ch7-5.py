import cv2
import pytesseract

pytesseract.pytesseract.tesseract_cmd="C:\\Program Files\\Tesseract-OCR\\tesseract.exe"
img = cv2.imread("car.jpg")
cv2.imshow("img", img)
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
cv2.imshow("gray", gray)
gblur = cv2.GaussianBlur(gray,(5,5),10)
cv2.imshow("GaussianBlur", gblur)
sobel = cv2.Sobel(gblur, cv2.CV_8U, 1, 0, ksize=1)
cv2.imshow("Sobel", sobel)
canny = cv2.Canny(sobel, 250, 100)
cv2.imshow("Canny", canny)
kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(40,40))
morph = cv2.morphologyEx(canny, cv2.MORPH_CLOSE, kernel)
cv2.imshow("Morphology", morph)
contours, hierarchy = cv2.findContours(morph, cv2.RETR_TREE,
                                       cv2.CHAIN_APPROX_SIMPLE)
img2 = img.copy()
cv2.drawContours(img2,contours, -1, (0,0,255), 3)
cv2.imshow("Contours", img2)
result = None
for contour in contours:
    x, y, w, h = cv2.boundingRect(contour)
    if w > 2 * h:        
        print("Detect Car License Plate!")
        result = img[y:y+h,x:x+w]        
        cv2.imshow("Plate", result)
        text = pytesseract.image_to_string(result, lang="eng")
        if text:
            print(text.strip())
            break        
cv2.waitKey(0)
cv2.destroyAllWindows()