import cv2, imutils

img = cv2.imread("penguins.png")
rotated_img = imutils.rotate(img, angle=90)
translated_img = imutils.translate(img, 25, -75)
cv2.imshow("Penquins:rotated", rotated_img)
cv2.imshow("Penguins:translated", translated_img)
cv2.waitKey(0)
cv2.destroyAllWindows()