from PIL import Image
import pytesseract

pytesseract.pytesseract.tesseract_cmd="C:\\Program Files\\Tesseract-OCR\\tesseract.exe"
img = Image.open("number.jpg")
text = pytesseract.image_to_string(img, lang="eng")
print(text.strip())
img = Image.open("traditional.jpg")
text = pytesseract.image_to_string(img, lang="chi_tra")
print(text.strip())
img = Image.open("simple.jpg")
text = pytesseract.image_to_string(img, lang="chi_sim")
print(text.strip())
