import cv2

img = cv2.imread("penguins.png")
fliped_img = cv2.flip(img, -1)
cv2.imshow("Penguins:fliped", fliped_img)
cv2.waitKey(0)
cv2.destroyAllWindows()