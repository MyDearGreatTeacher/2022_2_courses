import cv2
import imutils

img = cv2.imread("sample2.jpg")
img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
# Canny
edges = imutils.auto_canny(img_gray) 
cv2.imshow("Canny", edges)
# findContours
contours, hierarchy = cv2.findContours(edges,
                      cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
cv2.drawContours(img,contours, -1, (0,0,255), 3)  
cv2.imshow("Contours", img)        
cv2.waitKey(0)
cv2.destroyAllWindows()