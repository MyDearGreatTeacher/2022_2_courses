import cv2

img = cv2.imread("star.jpg")
# Erode
kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(5,5))
result = cv2.erode(img, kernel) 
cv2.imshow("ORIGINAL", img)
cv2.imshow("Erode", result)
cv2.waitKey(0)
cv2.destroyAllWindows()