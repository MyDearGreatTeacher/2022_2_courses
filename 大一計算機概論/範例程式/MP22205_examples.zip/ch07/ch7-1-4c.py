import cv2

img = cv2.imread("rectangle2.jpg")
# MORPH_OPEN
kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(7,7))
result = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel) 
# MORPH_CLOSE
kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(11,11))
result = cv2.morphologyEx(result, cv2.MORPH_CLOSE, kernel) 
cv2.imshow("ORIGINAL", img)
cv2.imshow("MORPH CLOSE", result)
cv2.waitKey(0)
cv2.destroyAllWindows()