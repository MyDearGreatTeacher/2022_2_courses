import cv2

img = cv2.imread("sample2.jpg", cv2.IMREAD_GRAYSCALE)
cv2.imshow("ORIGINAL", img)
# Canny
edges = cv2.Canny(img, 100, 200) 
cv2.imshow("Canny", edges)
# Sobel X
edges = cv2.Sobel(img, cv2.CV_64F, 1, 0, 3) 
cv2.imshow("Sobel X", edges)
# Sobel Y
edges = cv2.Sobel(img, cv2.CV_64F, 0, 1, 3) 
cv2.imshow("Sobel Y", edges)
cv2.waitKey(0)
cv2.destroyAllWindows()