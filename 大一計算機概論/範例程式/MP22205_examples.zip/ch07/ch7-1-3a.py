import cv2

img = cv2.imread("sample.jpg", cv2.IMREAD_GRAYSCALE)
cv2.imshow("ORIGINAL", img)
# Blur
result = cv2.blur(img, (5,5)) 
cv2.imshow("Blur", result)
# Gaussian Blur
result = cv2.GaussianBlur(img, (5,5), 1.5) 
cv2.imshow("Gaussian Blur", result)
# Median Blur
result = cv2.medianBlur(img, 5) 
cv2.imshow("Median Blur", result)
cv2.waitKey(0)
cv2.destroyAllWindows()