import cv2

img = cv2.imread("sample.jpg")
cv2.imshow("ORIGINAL", img)
# THRESH_BINARY
thresh = 127
maxValue = 255
th, result = cv2.threshold(img, thresh, maxValue,
                 cv2.THRESH_BINARY) 
cv2.imshow("BINARY", result)
# THRESH_BINARY_INV
th, result = cv2.threshold(img, thresh, maxValue,
                 cv2.THRESH_BINARY_INV) 
cv2.imshow("B_INV", result)
# THRESH_TRUNC
th, result = cv2.threshold(img, thresh, maxValue,
                 cv2.THRESH_TRUNC) 
cv2.imshow("TRUNC", result)
# THRESH_TOZERO
thresh = 200
th, result = cv2.threshold(img, thresh, maxValue,
                 cv2.THRESH_TOZERO) 
cv2.imshow("ZERO", result)
# THRESH_TOZERO_INV
th, result = cv2.threshold(img, thresh, maxValue,
                 cv2.THRESH_TOZERO_INV) 
cv2.imshow("Z_INV", result)
cv2.waitKey(0)
cv2.destroyAllWindows()