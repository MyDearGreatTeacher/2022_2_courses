from moviepy.editor import ImageSequenceClip

images = []
for i in range(4):
    images.append("imgs/ball" + str(i) +".jpg")

clip = ImageSequenceClip(images, fps=1)
clip.write_gif("demo.gif")

