import cv2

cap = cv2.VideoCapture('YouTube.mp4')

f_idx = 0
while(cap.isOpened()):
  ret, frame = cap.read()
  if ret:
      fname = "figures/frame"+str(f_idx)+".jpg"
      cv2.imwrite(fname, frame)
      print("將影格:",f_idx,"寫入圖檔:",fname)
      f_idx = f_idx + 1
  else:
      break

cap.release()

