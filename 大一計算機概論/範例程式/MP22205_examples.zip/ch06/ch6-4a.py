import cv2

img = cv2.imread("color/color0.jpg")
size = (img.shape[1], img.shape[0])
fps = 20
videofile = "colors.avi"
fourcc = cv2.VideoWriter_fourcc(*'XVID')
out = cv2.VideoWriter(videofile, fourcc, fps, size)
print("輸出檔名 :", videofile)
print("影片FPS :", fps)
print("影片尺寸 :", size) 
print("開始將圖檔寫入影片...")
for idx in range(10):
  fname = "color/color"+str(idx)+".jpg"
  print("寫入圖檔 :", fname)
  img = cv2.imread("color/color"+str(idx)+".jpg")
  out.write(img)
print("影片寫入完成...")
out.release()

