import cv2

img = cv2.imread("koala.jpg")
cv2.imshow("Koala", img)

cv2.waitKey(0)
cv2.destroyAllWindows()

