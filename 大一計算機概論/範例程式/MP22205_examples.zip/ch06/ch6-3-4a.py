from moviepy.editor import *

clip = VideoFileClip("使用fChart解統測與技競問題.mp4")
clip = clip.subclip(10,20)
clip = clip.volumex(10.2)

msg = "fchart tool"
txt_clip = TextClip(msg, fontsize=70, color='red', bg_color="yellow")
txt_clip = txt_clip.set_pos('center').set_duration(10)

video = CompositeVideoClip([clip, txt_clip])
video.write_videofile("Output3.webm")
