a = "1234"
print("變數a型別 = ", type(a))
b = int(a)
print("變數b型別 = ", type(b))
c = float(b)
print("變數c型別 = ", type(c))

