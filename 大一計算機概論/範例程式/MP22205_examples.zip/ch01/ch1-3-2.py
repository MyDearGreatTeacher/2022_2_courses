score1 = score2 = score3 = 25
print(score1, score2, score3)



