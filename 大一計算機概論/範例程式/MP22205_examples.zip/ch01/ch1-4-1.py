a = 1
b = 56789
print(type(a))
print(type(b))





