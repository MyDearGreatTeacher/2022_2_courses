x = True
y = False
print(type(x))
print(type(y))







