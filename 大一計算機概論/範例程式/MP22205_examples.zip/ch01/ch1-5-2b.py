x, y = 10, 20
s = "Y= {1} X= {0}".format(x, y)
print(s)

