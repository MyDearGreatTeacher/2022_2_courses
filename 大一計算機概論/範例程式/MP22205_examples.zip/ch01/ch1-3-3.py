x, y = 1, 2
print("X = ", x, "Y = ", y)
x, y = y, x
print("X = ", x, "Y = ", y)




