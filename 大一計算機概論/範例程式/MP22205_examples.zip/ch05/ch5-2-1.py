from tkinter import *

win = Tk()
win.title("Tkinter視窗")
Label(win, text="Python視窗程式").pack()
win.geometry("250x150")
win.mainloop()


