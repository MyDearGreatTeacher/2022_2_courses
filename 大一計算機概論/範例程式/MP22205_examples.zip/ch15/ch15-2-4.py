from linebot import LineBotApi

channel_token  = "<Channel access token>"

line_bot_api = LineBotApi(channel_token)
webhook = line_bot_api.get_webhook_endpoint()
print(webhook.endpoint)
print(webhook.active)
test_result = line_bot_api.test_webhook_endpoint()
print(test_result.success)
print(test_result.timestamp)
print(test_result.status_code)
print(test_result.reason)
print(test_result.detail)