from linebot import LineBotApi

channel_token  = "<Channel access token>"

WEBHOOK_URL = "https://4457-118-168-148-38.ngrok.io/callback"
line_bot_api = LineBotApi(channel_token)
line_bot_api.set_webhook_endpoint(WEBHOOK_URL)
webhook = line_bot_api.get_webhook_endpoint()
print(webhook.endpoint)
print(webhook.active)