with open("note.txt", "r") as fp:
    str1 = fp.read()
    print(str1)    