fp = open("note.txt", "r")
str1 = fp.read()
print(str1)
fp.close()    