fp = open("myfile.txt", "r")
print(fp.read())
fp.close()




