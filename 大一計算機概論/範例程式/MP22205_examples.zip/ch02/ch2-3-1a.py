t = int(input("請輸入氣溫: "))
if t >= 20 and t <= 22:
    print("加一件薄外套 !")
print("今天氣溫 = ", t)

