a, b = 3, 4
c = a < b
d = a == b 
print("c條件運算式(a < b)=", c)
print("d條件運算式(a == b)=", d)
print("NOT邏輯運算子: (not c)=", (not c))
print("AND邏輯運算子: (c and d)=", (c and d))
print("OR邏輯運算子: (c or d)=", (c or d))
