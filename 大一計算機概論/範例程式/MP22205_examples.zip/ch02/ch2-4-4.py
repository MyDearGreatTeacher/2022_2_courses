for i in range(1, 10):
    j = 1
    while j <= 9:
        print(str(i),"*",str(j),"=",str(i*j),"",end="")
        j = j + 1
    print("")
