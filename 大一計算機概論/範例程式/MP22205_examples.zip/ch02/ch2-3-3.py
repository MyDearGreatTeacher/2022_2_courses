h = int(input("輸入24小時制的小時數: "))
h = h-12 if h >= 12 else h
print("目前時間為 = ", h)
