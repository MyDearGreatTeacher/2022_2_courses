a, b, c = 3, 5, 2
if a > b and a > c:
    print("變數 a 最大!")
else:
    if b > c: 
        print("變數 b 最大!")
    else:
        print("變數 c 最大!")

