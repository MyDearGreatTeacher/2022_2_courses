s = 0
for i in range(1, 6):
    s = s + i
else:
    print("for迴圈結束!")
    print("總和 = ", s)
