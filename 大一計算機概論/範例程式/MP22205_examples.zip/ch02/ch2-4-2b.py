for c in range(1, 11, 2):
    print("c = ", c)


