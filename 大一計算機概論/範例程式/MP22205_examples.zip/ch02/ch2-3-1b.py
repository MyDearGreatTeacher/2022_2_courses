t = int(input("請輸入氣溫: "))
if 20 <= t <= 22:
    print("加一件薄外套!")
print("今天氣溫 = ", t)

