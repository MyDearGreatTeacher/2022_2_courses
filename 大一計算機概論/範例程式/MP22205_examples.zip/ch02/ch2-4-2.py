for a in range(5):
    print("a = ", a)



