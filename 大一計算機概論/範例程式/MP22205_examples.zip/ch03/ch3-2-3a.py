lst1 = [1, 5]
lst1.insert(1, 3)
print(lst1)

