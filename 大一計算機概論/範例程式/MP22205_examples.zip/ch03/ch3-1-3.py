ch1 = "A"
print("ch1 = " + ch1)
a = ord(ch1)
print("ord(ch1) = " + str(a))
a = chr(97)
print("chr(97) = " + a)
a = ord('B')
print("ord('B') = " + str(a))
