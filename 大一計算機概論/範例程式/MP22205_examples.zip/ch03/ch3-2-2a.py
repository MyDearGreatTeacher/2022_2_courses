lst1 = [1, 2, 3, 4, 5, 6]
lst1[1] = 10
lst1[2] = "Python"
print(lst1)
