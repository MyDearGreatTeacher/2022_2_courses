str1 = "Python程式設計" 
name1 = str("陳會安")
print("str1 = " + str1)
print(name1)
