lst2 = [[2, 4], ['cat', 'dog', 'bat'], [1, 3, 5]]
for e1 in lst2:
    for e2 in e1:
        print(e2, end=" ")

