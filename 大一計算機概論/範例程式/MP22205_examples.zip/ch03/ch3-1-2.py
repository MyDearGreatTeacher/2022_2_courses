str1 = "Python程式設計" 
for ch in str1:
    print(ch, end=" ")

