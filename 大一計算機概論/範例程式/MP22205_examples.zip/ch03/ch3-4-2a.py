d1 = {"chicken": 2, "dog": 4, "cat":3}
d1["cat"] = 4
print(d1)

