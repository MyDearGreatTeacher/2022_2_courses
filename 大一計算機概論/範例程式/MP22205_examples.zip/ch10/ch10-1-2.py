from apscheduler.schedulers.blocking import BlockingScheduler
import time, datetime 

def task(text):
    localtime = time.asctime(time.localtime(time.time()))
    print(localtime, ": 執行任務...", text)
scheduler = BlockingScheduler(timezone="Asia/Taipei") 
run_date = datetime.date(2022,1,15)
scheduler.add_job(task, "date", run_date=run_date, args=["工作1"])
run_date = datetime.datetime(2022,1,15,19,2,0)
scheduler.add_job(task, "date", run_date=run_date, args=["工作2"])
run_date = "2022-1-15 19:03:00"
scheduler.add_job(task, "date", run_date=run_date, args=["工作3"])
try:
    scheduler.start()
except (KeyboardInterrupt, SystemExit):
    scheduler.shutdown() 
