import pyautogui

print(pyautogui.onScreen(500, 600))
pos = (0, 10000)
print(pyautogui.onScreen(pos))
