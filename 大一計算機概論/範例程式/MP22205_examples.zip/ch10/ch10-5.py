from playwright.sync_api import sync_playwright
import time

with sync_playwright() as p:
    browser = p.chromium.launch(headless=False)
    page = browser.new_page()
    page.goto("https://duckduckgo.com")
    page.fill("#search_form_input_homepage", "Playwright")
    page.click("#search_button_homepage")
    time.sleep(3)
    page.screenshot(path="example3.png")
    items = page.query_selector_all(".result__a")
    for item in items:
        print(item.text_content(), end=" : ")
        print(item.get_attribute("href"))
    browser.close()