import pyautogui

pyautogui.alert("測試alert訊息視窗...", "訊息視窗", button="確定")
ret = pyautogui.confirm("確認結束!", buttons=["確認", "取消"])
print(ret)
ret = pyautogui.confirm("請輸入數字", "輸入數字", buttons=range(10))
print(ret)
ret = pyautogui.prompt("請輸入姓名", "使用者", default="陳會安")
print(ret)














