import pyautogui

box = pyautogui.locateOnScreen("images/start_button.png")
print(box)
pos = pyautogui.center(box)
print(pos)