import pyautogui

pyautogui.click(300, 300, clicks=1)
pyautogui.hotkey('ctrl', 'a') # Ctrl+A
pyautogui.hotkey('ctrl', 'c') # Ctrl+C
pyautogui.click(400, 400, clicks=1)
pyautogui.hotkey('ctrl', 'v') # Ctrl+V
