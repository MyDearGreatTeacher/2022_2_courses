import pyautogui

print(pyautogui.size()) 
width, height = pyautogui.size()
print(width, height)
print(pyautogui.position()) 
x, y = pyautogui.position()
print(x, y) 