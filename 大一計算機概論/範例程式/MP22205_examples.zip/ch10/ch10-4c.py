import pyautogui
import time

win_btn = pyautogui.locateOnScreen("images/start_button.png")
try:
    loc = pyautogui.center(win_btn)
    pyautogui.click(loc)
    pyautogui.typewrite("paint")
    pyautogui.typewrite(["enter"])
    print("已經成功開啟小畫家...")
    time.sleep(2)
    pyautogui.moveTo(300, 300, duration=1)
    pyautogui.click()
    distance = 200
    while distance > 10:
        pyautogui.dragRel(distance, 0, duration = 0.2)
        distance = distance - 20
        pyautogui.dragRel(0, distance, duration = 0.2)
        pyautogui.dragRel(-distance, 0, duration = 0.2)
        distance = distance - 20
        pyautogui.dragRel()
        pyautogui.dragRel(0, -distance, duration = 0.2)
except:
    print("開啟失敗...")
