import pyautogui

pyautogui.click(300, 300, clicks=1)
pyautogui.typewrite('# Hello world!', interval=1)
pyautogui.typewrite(['enter'])
pyautogui.typewrite(["#", " ", "a", "b", "c", "enter"])

