import pyautogui

pyautogui.click(300, 300, clicks=3, interval=2, button='right')

