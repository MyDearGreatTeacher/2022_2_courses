import pyautogui

pyautogui.PAUSE = 2.5
print(pyautogui.PAUSE)
pyautogui.FAILSAFE = False
print(pyautogui.FAILSAFE)