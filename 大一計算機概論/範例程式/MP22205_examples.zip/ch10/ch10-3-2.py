from playwright.sync_api import sync_playwright
import time

with sync_playwright() as p:
    browser = p.chromium.launch(headless=False)
    page = browser.new_page()
    page.goto("https://fchart.github.io/form.html")
    page.fill("#quantity", "2")
    page.fill("#price", "420")
    page.uncheck("#discount")
    page.select_option("#tip","20")
    page.click("#cal")
    time.sleep(2)
    item = page.query_selector('#amount')
    print(item.input_value())
    browser.close()