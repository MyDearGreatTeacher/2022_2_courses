import pyautogui

win_btn = pyautogui.locateOnScreen("images/start_button.png")
try:
    loc = pyautogui.center(win_btn)
    pyautogui.click(loc)
    print("成功開啟開始功能表!")
    pyautogui.typewrite("firefox")
    pyautogui.typewrite("\n")
    print("已經成功開啟Firefox...")
except:
    print("開啟失敗...")