import pyautogui

print(pyautogui.KEYBOARD_KEYS)


