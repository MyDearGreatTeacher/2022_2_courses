import pyautogui

pyautogui.moveTo(300, 300, duration=1)
pyautogui.moveTo(400, 400, duration=2)
pyautogui.moveRel(100, 100, duration=1)