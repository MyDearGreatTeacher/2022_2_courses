from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=False)
    page = browser.new_page()
    page.goto("https://webscraper.io/test-sites/e-commerce/allinone/computers/laptops")
    all_items = page.query_selector_all(".thumbnail")
    laptops = []
    for item in all_items:
        laptop = {}
        name = item.query_selector("a.title")
        laptop["name"] = name.text_content()
        laptop["url"] = name.get_attribute("href")
        price = item.query_selector("h4.price")
        laptop["price"] = price.text_content()
        reviews = item.query_selector("p.pull-right")
        laptop["reviews"] = reviews.inner_text()
        laptops.append(laptop)
    print(laptops)
    browser.close()