import pyautogui

win_btn = pyautogui.locateOnScreen("images/start_button.png")
try:
    loc = pyautogui.center(win_btn)
    pyautogui.click(loc)
    print("成功開啟開始功能表!")
    pyautogui.typewrite("cmd")
    pyautogui.typewrite(["enter"])
    print("已經成功開啟命令提示字元視窗...")
except:
    print("開啟失敗...")


