from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.launch(headless=False)
    page = browser.new_page()
    page.goto("https://www.google.com")
    page.fill("input[name=q]", "Playwright GitHub")
    page.click("input[type=submit]")
    page.wait_for_selector("text=microsoft/Playwright")
    page.screenshot(path="example2.png")
    browser.close()