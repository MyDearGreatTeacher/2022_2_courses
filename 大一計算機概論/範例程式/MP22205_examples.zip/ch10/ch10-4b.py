import pyautogui
import time

win_btn = pyautogui.locateOnScreen("images/start_button.png")
try:
    loc = pyautogui.center(win_btn)
    pyautogui.click(loc)
    print("成功開啟開始功能表!")
    pyautogui.typewrite("firefox")
    pyautogui.typewrite("\n")
    print("已經成功開啟Firefox...")
    time.sleep(3)
    print("進入GMail")
    pyautogui.hotkey("alt", 'd')
    pyautogui.typewrite("https://accounts.google.com/signin/v2/identifier?continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&service=mail&ltmpl=default&flowName=GlifWebSignIn&flowEntry=ServiceLogin")
    pyautogui.typewrite(["enter"])
except:
    print("開啟失敗...")
    