import pyautogui

pyautogui.dragTo(200, 200, duration=5)
pyautogui.dragRel(200, 200, duration=5)
