import pyautogui

pyautogui.screenshot("screen1.png")














