import pyautogui

pyautogui.click(300, 300, clicks=1)
pyautogui.keyDown('ctrl')
pyautogui.keyDown('a')
pyautogui.keyUp('a')
pyautogui.keyUp('ctrl')















